import {useState} from "react"
import "./styles.css"

function App() {
  const [total,setTotal]=useState({
    score:76,
    wicket:2,
    over:50
  })
  const handle=(val,part)=>{
    if (part == "score") {
      setTotal({
        score: total.score + val,
        wicket: total.wicket,
        over: total.over,
      });
    } else if (part == "wicket") {
      setTotal({
        score: total.score,
        wicket: total.wicket + val,
        over: total.over,
      });
    } else if (part == "over") {
      let ball=(total.over+val/6)
      setTotal({
        score: total.score,
        wicket: total.wicket,
        over: ((total.over + val)/6),
      });
    }
  }
  return (
    <div className="App">
      <h3>India:</h3>
      <div className="banner">
        <div>
          Score:{" "}
          <h1 className="scoreCount">
            {
              // show "score" here
              total.score
            }
          </h1>
        </div>
        <div>
          Wicket:{" "}
          <h1 className="wicketCount">
            {
              // show wicket here
              total.wicket
            }
          </h1>
        </div>

        <div>
          Over:{" "}
          <h1 className="overCount">
            {
              total.over
              // Show Over here in the format: "over.ball" eg: 4.5 means 4th over and 5th ball
              // if 1 more ball is thrown then over is now 5.0
              // you have to write logic to form this string from current ball number.
            }
          </h1>
        </div>
      </div>

      <div className="addScore">
        Add Score
        {/* these buttons should add the respective amount in the score */}
        <button
          onClick={() => {
            handle(1, "score");
          }}
          className="addScore1"
        >
          Add 1
        </button>
        <button
          onClick={() => {
            handle(4, "score");
          }}
          className="addScore4"
        >
          Add 4
        </button>
        <button
          onClick={() => {
            handle(6, "score");
          }}
          className="addScore6"
        >
          Add 6
        </button>
      </div>

      <div className="addWicket">
        Add Wicket
        {/* Increase the count of wicket */}
        <button
          onClick={() => {
            handle(1, "wicket");
          }}
        >
          Add 1 wicket
        </button>
      </div>

      <div className="addBall">
        Add ball
        {/* Increase the total number of balls thrown here. */}
        <button
          onClick={() => {
            handle(1, "over");
          }}
        >
          Add 1
        </button>
      </div>

      {/* If score reaches greater than 100, show text "India Won" without quotes in h1 tag with class name 'status' */}
    </div>
  );
}

export default App;