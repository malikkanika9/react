import "./styles.css";

export default function App() {
  const term=["services","projects","about"]
    return (
    <div className="App">
      <div className="container">
<div className="right">LOGOBAKERY</div>
<div className="middle">
{term.map((e)=>{
return <Term term={e}/>;

})}

</div>
<button className="btn">Contact</button>

      </div>
    </div>
  );
}
function Term({term}){
  return <p className="logic">{term}</p>;
}