import { useState } from "react"
import { useEffect } from "react";

export const Counter=()=>{

    const [count,setCount]=useState(10);
  
useEffect(()=>{
let id=setInterval(()=>{
setCount((prevalue)=>{
if(prevalue<=0)
{
    clearInterval(id);
    return 0;
}
    return prevalue-1;
})

},1000)

return()=>{
    clearInterval(id);
}

},[])
    return (

        <div>
<h3>count:{count}</h3>

        </div>
    )
}