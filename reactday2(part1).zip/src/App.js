import "./styles.css";

export default function App() {
  const mobile = ["ANDROID", "BLACKBERRY", "IPHONE", "WINDOW"];
  const Manufacture = ["Samsung", "HTC", "VIVO", "MI"];
  return (
    <div className="App">
      <div>
        <h1>Mobile Operating System</h1>
        <ul>
          {mobile.map((e) => {
            return <li>{e}</li>;
          })}
        </ul>
      </div>
      <div>
        <h1>Mobile Manufactures</h1>
        <ul>
          {Manufacture.map((e) => {
            return <li>{e}</li>;
          })}
        </ul>
      </div>
    </div>
  );
}
