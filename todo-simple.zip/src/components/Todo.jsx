import { useState } from "react";
import { TodoInput } from "./TodoInput";

function Todo() {
  const [todoslist, setTodoslist] = useState([]);
  const getData = (todo) => {
    console.log("re", todo);
    setTodoslist([...todoslist, todo]);
  };
  return (
    <div>
      <TodoInput getData={getData} />
      {todoslist.map((e) => (
        <div className="dat">{e}</div>
      ))}
    </div>
  );
}

export { Todo };
