import { useState } from "react";

export const TodoInput = ({ getData }) => {
  const [text, setText] = useState("");
  return (
    <div>
      <input
        className="in"
        type="text"
        onChange={(e) => {
          //console.log(e.target.value)
          setText(e.target.value);
        }}
        placeholder="Write Something"
      />
      <button
        className="btn"
        onClick={() => {
          getData(text);
        }}
      >
        +
      </button>
    </div>
  );
};
