import{sum} from "./calc";
//const sum=require("./calc")
console.log("hello")
console.log(sum(5,5));