function sum(a,b)
{
    return a+b;
}

export{sum};

const root=document.getElementById("root");
const h1=document.createElement("h1")
h1.innerText="hello world"
h1.setAttribute("class","redtext")
root.append(h1);
