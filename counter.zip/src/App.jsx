import { Category } from "./components/category";
import {useState} from "react";
import "./styles.css";

export default function App() {
  const[counter,setCounter]= useState(0);
let cls;
//counter%2==0 ? cls="green" : cls="red";
  const handle=(value)=>{
   // if(counter>=10 || counter<=0){return}
  setCounter(counter+value);

  }
  const handle1=(value)=>{
    // if(counter>=10 || counter<=0){return}
   setCounter(counter*value);
 
   }
    return (
    <div className="App">
<h3 className={`${counter%2===0 ? "green": "red"}`}>Counter:{counter}</h3>
<button onClick={()=>{
handle(1);

}}>Add 1</button>
<button onClick={()=>{
 handle(-1);
}}>sub 1</button>
<button onDoubleClick={()=>{
 handle1(2);
}}>product</button>
    </div>


  );
}
